// LifeHub — main app
// Personal dashboard with sidebar nav switching between Today / Tasks / Notes views.

const { useState, useMemo, useEffect, useRef } = React;

// ── Mock data ──────────────────────────────────────────────────
const TODAY_TASKS = [
  { id: 1, text: "Review Q2 product brief", chip: { label: "Work", cls: "work" }, due: "10:00", done: false, focus: true },
  { id: 2, text: "Pick up dry cleaning",      chip: { label: "Home", cls: "home" }, due: "Today", done: false },
  { id: 3, text: "30-min strength session",   chip: { label: "Health", cls: "health" }, due: "6pm",  done: true  },
  { id: 4, text: "Reply to landlord re: renewal", chip: { label: "Home", cls: "home" }, due: "Today", done: false, urgent: true },
  { id: 5, text: "Draft retrospective notes", chip: { label: "Focus", cls: "focus" }, due: "Thu",   done: false },
];

const UPCOMING_BY_SECTION = {
  "This week": [
    { id: 10, text: "Call mom for her birthday", chip: { label: "Home", cls: "home" }, due: "Wed" },
    { id: 11, text: "Submit travel reimbursement", chip: { label: "Work", cls: "work" }, due: "Thu" },
    { id: 12, text: "Renew passport application", chip: { label: "Home", cls: "home" }, due: "Fri" },
    { id: 13, text: "Coffee with Priya",         chip: { label: "Focus", cls: "focus" }, due: "Fri" },
  ],
  "Next week": [
    { id: 20, text: "Annual review prep",  chip: { label: "Work", cls: "work" },   due: "Jun 3" },
    { id: 21, text: "Bike tune-up",        chip: { label: "Home", cls: "home" },   due: "Jun 4" },
    { id: 22, text: "Dentist follow-up",   chip: { label: "Health", cls: "health" }, due: "Jun 5" },
  ],
  "Someday": [
    { id: 30, text: "Read 'A Pattern Language'", chip: { label: "Focus", cls: "focus" } },
    { id: 31, text: "Plant herbs on balcony",    chip: { label: "Home",  cls: "home"  } },
    { id: 32, text: "Try sourdough recipe",      chip: { label: "Home",  cls: "home"  } },
  ],
};

const EVENTS = [
  { time: "9:00",  end: "9:30",   title: "Morning standup",      sub: "Engineering · Google Meet", attendees: ["JM","RC","AT","+3"], cls: "" },
  { time: "10:30", end: "11:15",  title: "1:1 with Priya",       sub: "Coffee · Blue Bottle",       attendees: ["PS"], cls: "b1" },
  { time: "14:00", end: "15:00",  title: "Design review",        sub: "Studio room A",               attendees: ["MN","RC","JM"], cls: "b2" },
];

const HABITS = [
  { name: "Read 20 min",    icon: "book",    cells: [3,2,3,3,1,2,3,0,0] },
  { name: "Move",           icon: "run",     cells: [3,3,2,3,3,3,1,3,0] },
  { name: "Hydrate",        icon: "droplet", cells: [2,3,3,2,3,3,2,2,1] },
  { name: "No screens 9pm", icon: "clock",   cells: [3,1,2,3,0,2,3,3,0] },
];

const NOTES = [
  { id: 1, title: "Trip ideas — late summer", body: "Lisbon for a week then 3 nights in the Algarve. Check flights mid-June. Friend mentioned the tile museum and pastéis at Manteigaria…", tag: "travel", time: "2h ago", pinned: true, serif: true },
  { id: 2, title: "Book notes: Slow Productivity", body: "Three principles — do fewer things, work at a natural pace, obsess over quality. The 'reasonable workload' calculation has been useful when planning the week.", tag: "reading", time: "yesterday" },
  { id: 3, title: "Things to ask the doctor", body: "Sleep quality has been off. Mention waking at 3am most nights. Ask about vit. D levels and whether the current dose still makes sense.", tag: "health", time: "Mon" },
  { id: 4, title: "Apartment maintenance", body: "Kitchen faucet drip — needs new cartridge (Moen 1225). Bathroom fan rattles at startup. Hall light flickers every few days.", tag: "home", time: "Mon" },
  { id: 5, title: "Recipe — miso butter pasta", body: "Toast 3 tbsp white miso with butter, add a splash of pasta water, finish with lemon zest and chili crisp. Simple weeknight win.", tag: "cooking", time: "last week" },
  { id: 6, title: "Gift ideas", body: "Dad — that wool overshirt he keeps mentioning. Sis — pottery class voucher at the studio on Mission. Both birthdays in July.", tag: "personal", time: "last week" },
];

const HABIT_ICON = { book: IconBook, run: IconRun, clock: IconClock, droplet: IconDroplet };

// ── Nav config ─────────────────────────────────────────────────
const NAV = [
  { group: "Workspace", items: [
    { id: "today",    label: "Today",     icon: IconHome,        count: "5" },
    { id: "tasks",    label: "Tasks",     icon: IconCheckSquare, count: "23" },
    { id: "calendar", label: "Calendar",  icon: IconCalendar },
    { id: "notes",    label: "Notes",     icon: IconNote,        count: "142" },
    { id: "inbox",    label: "Inbox",     icon: IconInbox,       count: "3" },
  ]},
  { group: "Library", items: [
    { id: "captures", label: "Captures",  icon: IconCamera },
    { id: "saved",    label: "Saved",     icon: IconBookmark },
    { id: "tags",     label: "Tags",      icon: IconHash },
  ]},
];

// ── Sidebar ────────────────────────────────────────────────────
function Sidebar({ view, setView }) {
  return (
    <aside className="side">
      <div className="brand">
        <div className="brand-mark">L</div>
        <div className="brand-name">LifeHub</div>
        <div className="brand-sub mono">v0.4</div>
      </div>

      {NAV.map(group => (
        <div key={group.group} className="nav-group">
          <div className="nav-label">{group.group}</div>
          {group.items.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                className={"nav-item" + (view === item.id ? " active" : "")}
                onClick={() => setView(item.id)}>
                <Icon />
                <span>{item.label}</span>
                {item.count && <span className="nav-count">{item.count}</span>}
              </button>
            );
          })}
        </div>
      ))}

      <div className="side-bottom">
        <button className="nav-item"><IconSettings /><span>Settings</span></button>
        <div className="quota">
          <div>Local storage</div>
          <div className="quota-bar"><i /></div>
          <div style={{ marginTop: 4, fontSize: 10.5 }}>1.2 GB of 3.0 GB used</div>
        </div>
      </div>
    </aside>
  );
}

// ── Topbar ─────────────────────────────────────────────────────
const VIEW_TITLES = {
  today: "Today", tasks: "Tasks", calendar: "Calendar", notes: "Notes",
  inbox: "Inbox", captures: "Captures", saved: "Saved", tags: "Tags",
};
function Topbar({ view }) {
  return (
    <div className="topbar">
      <div className="crumbs">
        <span>Workspace</span>
        <IconChevron />
        <b>{VIEW_TITLES[view] || "Today"}</b>
      </div>
      <div className="search">
        <IconSearch />
        <input placeholder="Search notes, tasks, captures…" />
        <kbd>⌘K</kbd>
      </div>
      <div className="top-actions">
        <button className="icon-btn" title="Notifications"><IconBell /></button>
        <button className="icon-btn" title="New capture"><IconCamera /></button>
        <div className="avatar">JM</div>
      </div>
    </div>
  );
}

// ── Today view ─────────────────────────────────────────────────
function TaskRow({ t, onToggle }) {
  return (
    <div className={"task" + (t.done ? " done" : "")}>
      <div className={"check" + (t.done ? " done" : "")} onClick={() => onToggle && onToggle(t.id)}>
        <IconCheck />
      </div>
      <div className="task-text">{t.text}</div>
      <div className="task-meta">
        {t.chip && <span className={"chip " + (t.chip.cls || "")}>{t.chip.label}</span>}
        {t.due && <span className={t.urgent ? "due-soon" : ""}>{t.due}</span>}
      </div>
    </div>
  );
}

function HabitRow({ h }) {
  const Icon = HABIT_ICON[h.icon] || IconCheck;
  return (
    <div className="habit-row">
      <div className="habit-name">
        <div className="ico"><Icon /></div>
        {h.name}
      </div>
      <div className="habit-cells">
        {h.cells.map((v, i) => (
          <div key={i}
               className={"habit-cell" + (v ? " f" + v : "") + (i === h.cells.length - 2 ? " today" : "")}
               title={["Sat","Sun","Mon","Tue","Wed","Thu","Fri","Sat","Sun"][i]} />
        ))}
      </div>
    </div>
  );
}

function TodayView({ tasks, toggleTask }) {
  const focus = tasks.filter(t => t.focus);
  const rest  = tasks.filter(t => !t.focus);
  const done  = tasks.filter(t => t.done).length;

  return (
    <>
      <div className="page-head">
        <div>
          <div className="hello">Good morning, <em>James</em>.</div>
          <div className="date-strip" style={{ marginTop: 10 }}>
            Tuesday, May 26 <span className="dot" />
            <span className="stat-pill"><span className="dot" /><b>{done}</b> of {tasks.length} done</span>
            <span style={{ display: "inline-block", width: 8 }} />
            <span className="stat-pill">Streak <b>12 days</b></span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button className="tool-btn"><IconCalendar /> Plan day</button>
          <button className="btn-primary"><IconPlus /> Quick add <span className="kbd">N</span></button>
        </div>
      </div>

      <div className="grid">
        <div className="col">
          {/* Quick capture */}
          <div className="capture">
            <div className="capture-hd">
              <span className="pulse" /> Quick capture · stored locally
            </div>
            <textarea className="capture-input" rows="2" placeholder="Jot a note, paste a link, or scan a receipt…" />
            <div className="capture-foot">
              <div className="capture-tools">
                <button className="tool-btn"><IconCamera /> Photo</button>
                <button className="tool-btn"><IconMic /> Voice</button>
                <button className="tool-btn"><IconPaperclip /> File</button>
                <button className="tool-btn"><IconHash /> Tag</button>
              </div>
              <button className="btn-primary">Save <span className="kbd">↵</span></button>
            </div>
          </div>

          {/* Focus tasks */}
          <div className="card">
            <div className="card-hd">
              <h3>Focus <span className="tag">3 tasks</span></h3>
              <span className="more">View all →</span>
            </div>
            <div className="card-body">
              {focus.map(t => <TaskRow key={t.id} t={t} onToggle={toggleTask} />)}
              {rest.slice(0,3).map(t => <TaskRow key={t.id} t={t} onToggle={toggleTask} />)}
              <div className="add-task">
                <div className="plus"><IconPlus /></div>
                <span>Add a task…</span>
              </div>
            </div>
          </div>

          {/* Calendar peek */}
          <div className="card">
            <div className="card-hd">
              <h3>Today's schedule</h3>
              <span className="more">Open calendar →</span>
            </div>
            <div className="card-body">
              {EVENTS.map((e, i) => (
                <div key={i} className="cal-row">
                  <div className="cal-time">
                    <b>{e.time}</b>{e.end}
                  </div>
                  <div className={"cal-event " + e.cls}>
                    <div className="cal-title">{e.title}</div>
                    <div className="cal-sub">{e.sub}</div>
                    <div className="cal-attendees">
                      {e.attendees.map((a, j) => <div key={j} className="av">{a}</div>)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="col">
          {/* Habits */}
          <div className="card">
            <div className="card-hd">
              <h3>Habits <span className="tag">Week 21</span></h3>
              <span className="more">···</span>
            </div>
            <div className="card-body">
              <div className="habit-grid">
                {HABITS.map(h => <HabitRow key={h.name} h={h} />)}
              </div>
            </div>
          </div>

          {/* Recent notes */}
          <div className="card">
            <div className="card-hd">
              <h3>Recent notes</h3>
              <span className="more">All notes →</span>
            </div>
            <div className="card-body">
              {NOTES.slice(0, 3).map(n => (
                <div key={n.id} className="note-card">
                  <div className="note-title">{n.title}</div>
                  <div className="note-prev">{n.body}</div>
                  <div className="note-meta">
                    <span>{n.tag}</span><span className="dot" /><span>{n.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Inbox preview */}
          <div className="card">
            <div className="card-hd">
              <h3>Inbox <span className="tag">3 new</span></h3>
              <span className="more">Open inbox →</span>
            </div>
            <div className="card-body">
              {[
                { t: "Receipt — Whole Foods", s: "$84.20 · auto-scanned · 4 items" },
                { t: "Article saved from Safari", s: "On craftsmanship and small studios" },
                { t: "Voice memo — 0:47", s: "Idea about the weekend cabin trip" },
              ].map((it, i) => (
                <div key={i} className="task">
                  <div className="ico" style={{ width:22, height:22, borderRadius:6, background:"var(--bg-2)", display:"grid", placeItems:"center" }}>
                    <IconArrow style={{ width:12, height:12, color:"var(--muted)" }} />
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div className="task-text" style={{ fontSize:13 }}>{it.t}</div>
                    <div style={{ fontSize:11.5, color:"var(--muted)", marginTop:1 }}>{it.s}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ── Tasks view ─────────────────────────────────────────────────
function TasksView({ tasks, toggleTask }) {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? tasks
                 : filter === "today" ? tasks
                 : filter === "open" ? tasks.filter(t => !t.done)
                 : tasks.filter(t => t.done);
  return (
    <>
      <div className="view-head">
        <div>
          <div className="view-title">Tasks</div>
          <div className="view-sub">{tasks.filter(t => !t.done).length} open · {tasks.filter(t => t.done).length} done today</div>
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div className="filter-bar">
            {[["all","All"],["today","Today"],["open","Open"],["done","Done"]].map(([k,l]) => (
              <button key={k} className={filter===k?"on":""} onClick={() => setFilter(k)}>{l}</button>
            ))}
          </div>
          <button className="btn-primary"><IconPlus /> New task</button>
        </div>
      </div>

      <div className="task-section">
        <div className="task-section-hd">
          <div className="ttl">Today</div>
          <div className="cnt">{filtered.length} items</div>
        </div>
        {filtered.map(t => <TaskRow key={t.id} t={t} onToggle={toggleTask} />)}
        <div className="add-task">
          <div className="plus"><IconPlus /></div>
          <span>Add a task… <span className="kbd" style={{ marginLeft: 4 }}>⏎</span></span>
        </div>
      </div>

      {Object.entries(UPCOMING_BY_SECTION).map(([section, items]) => (
        <div className="task-section" key={section}>
          <div className="task-section-hd">
            <div className="ttl">{section}</div>
            <div className="cnt">{items.length} items</div>
          </div>
          {items.map(t => <TaskRow key={t.id} t={t} />)}
        </div>
      ))}
    </>
  );
}

// ── Notes view ─────────────────────────────────────────────────
function NotesView() {
  const [tag, setTag] = useState("all");
  const tags = ["all", ...Array.from(new Set(NOTES.map(n => n.tag)))];
  const filtered = tag === "all" ? NOTES : NOTES.filter(n => n.tag === tag);
  return (
    <>
      <div className="view-head">
        <div>
          <div className="view-title">Notes</div>
          <div className="view-sub">{NOTES.length} notes · {NOTES.filter(n => n.pinned).length} pinned</div>
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          <button className="tool-btn"><IconFilter /> Sort: recent</button>
          <button className="btn-primary"><IconPlus /> New note</button>
        </div>
      </div>

      <div className="filter-bar" style={{ display: "inline-flex", marginBottom: 22 }}>
        {tags.map(t => (
          <button key={t} className={tag===t?"on":""} onClick={() => setTag(t)}>
            {t === "all" ? "All" : "#" + t}
          </button>
        ))}
      </div>

      <div className="notes-grid">
        {filtered.map(n => (
          <div key={n.id} className={"note-tile" + (n.pinned ? " pinned" : "")}>
            <h4 className={n.serif ? "serif" : ""}>{n.title}</h4>
            <div className="body">{n.body}</div>
            <div className="foot">
              {n.pinned && <span className="pin">Pinned</span>}
              <span>#{n.tag}</span>
              <span>·</span>
              <span>{n.time}</span>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ── Generic placeholder for other nav items ────────────────────
function PlaceholderView({ view }) {
  return (
    <div style={{ paddingTop: 80, textAlign: "center", color: "var(--muted)" }}>
      <div style={{ fontFamily: "Instrument Serif, serif", fontSize: 64, color: "var(--ink)", lineHeight: 1 }}>
        {VIEW_TITLES[view]}
      </div>
      <div style={{ marginTop: 16 }}>This surface is wired but not designed in this exploration.</div>
      <div style={{ marginTop: 4, fontSize: 12 }}>Try <span className="kbd">Today</span>, <span className="kbd">Tasks</span>, or <span className="kbd">Notes</span> from the sidebar.</div>
    </div>
  );
}

// ── App root ───────────────────────────────────────────────────
function App() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  const [tasks, setTasks] = useState(TODAY_TASKS);
  const view = t.view || "today";

  // Apply accent color as CSS custom property
  useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);

  const toggleTask = (id) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  let content;
  if      (view === "today") content = <TodayView tasks={tasks} toggleTask={toggleTask} />;
  else if (view === "tasks") content = <TasksView tasks={tasks} toggleTask={toggleTask} />;
  else if (view === "notes") content = <NotesView />;
  else                       content = <PlaceholderView view={view} />;

  return (
    <div className="app"
         data-theme={t.dark ? "dark" : "light"}
         data-density={t.density}
         data-screen-label={"01 " + (VIEW_TITLES[view] || "Today")}>
      <Sidebar view={view} setView={(v) => setTweak("view", v)} />
      <div className="main">
        <Topbar view={view} />
        <div className="content">{content}</div>
      </div>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
                    options={["#5C6B4A", "#8C6F4A", "#4A6FA5", "#9A4F5C", "#3D3D3D"]}
                    onChange={(v) => setTweak("accent", v)} />
        <TweakToggle label="Dark mode" value={t.dark}
                     onChange={(v) => setTweak("dark", v)} />
        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density}
                    options={["compact", "regular", "comfy"]}
                    onChange={(v) => setTweak("density", v)} />
        <TweakSection label="View" />
        <TweakSelect label="Jump to" value={t.view}
                     options={["today", "tasks", "notes", "calendar", "inbox", "captures"]}
                     onChange={(v) => setTweak("view", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
